/* See LICENSE file for copyright and license details. */

/* appearance */
static const unsigned int borderpx  = 0;        /* border pixel of windows */
static const unsigned int snap      = 32;       /* snap pixel */
static const unsigned int systraypinning = 0;   /* 0: sloppy systray follows selected monitor, >0: pin systray to monitor X */
static const unsigned int systrayonleft = 0;   	/* 0: systray in the right corner, >0: systray on left of status text */
static const unsigned int systrayspacing = 2;   /* systray spacing */
static const int systraypinningfailfirst = 1;   /* 1: if pinning fails, display systray on the first monitor, False: display systray on the last monitor*/
static const int showsystray        = 1;     /* 0 means no systray */
static const int showbar            = 1;     /* 0 means no bar */
static const int swallowfloating    = 0;     /* 1 means swallos floating windows by default*/
static const int topbar             = 1;     /* 0 means bottom bar */
static const char *fonts[]          = { "jetbrains:size=16" }; //selected font for the panel, change that if desired, but alacritty does require a monospace font 
static const char dmenufont[]       = "jetbrains:size=16"; //selected font for demnu
static const char normbgcolor[]     = "#222222";
static const char normbordercolor[] = "#444444";
static const char normfgcolor[]     = "#bbbbbb";
static const char selfgcolor[]      = "#eeeeee";
static const char selbgcolor[]      = "#70327e"; 
static const char selbordercolor[]  = "#70327e";
//change this color to whatever you like, I don't like the default cyancolor. Use a colorpickertool to find the desired color. 

//Here the colors which you defined above will be set for the different parts of the panel
static const char *colors[][3]      = {
	/*               fg         bg         border   */
	[SchemeNorm] = { normfgcolor, normbgcolor, normbordercolor },
	[SchemeSel]  = { selfgcolor, selbgcolor,  selbordercolor  },
};

/* Here you name the 'tags' (workspaces), you can also use emoji's, like the awesome pictures, just copypaste it here */
static const char *tags[] = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" , "11", "12", "13", "14", "15", "16"};

/*This defines rules for how to open programs. The one for Gimp is there by default to make Gimp open the normal way because of the multiple floating windows, maybe not required anymore.
 * The ones for the terminals are required for the noswallow patch, this patch hides the terminal for the user when he starts a program without & after it, after that program closes the terminal gets shown again. 
 * The one for "Event Tester" is to make xev behave properly, you can use xev to find the hexadecimal codes of keys on your keyboard, which you can use to define hotkeys below. 
 * The other rules are to open programs on fixed workspaces. For example Deadbeef always opens on workspace 10, Telegram opens on workspace 3. 
 * Though technically incorrect you can think of 1 << n as 1+n to know on which workspace it opens. Technically it is about bitshifts and an XOR-operation, it is explained on the website from dwm.
 * Find the required class/instance/title by typing xprop in a terminal and clicking on the window of that program.*/ 
static const Rule rules[] = {
	/* xprop(1):
	 *	WM_CLASS(STRING) = instance, class
	 *	WM_NAME(STRING) = title
	 */
	/* class      		instance    title       tags mask     isfloating   isterminal  noswallow   monitor */
	{ "Gimp",      		NULL,       NULL,       	0,        1,       0,		0,		-1 },
    { "steam",      	NULL,       NULL,       	1 << 8,	  0,       0,		0,		-1 }, 
	{ "Steam",			NULL,	    NULL, 			1 << 8,	  0,       0,       0,		-1 },
	{ "Lutris",   		NULL,       NULL,       	1 << 8,	  0,       0,		0,		-1 },
	{ "Kotatogram",		 NULL,	    NULL,       	1 << 2,   0,       0,		0,		-1 },
	{ "Telegram",   	NULL,	    NULL,       	1 << 2,   0,       0,		0,		-1 },
    { "Deadbeef",   	NULL,       NULL,       	1 << 9,   0,       0,		0,		-1 },
	{ "Hollow Knight", 	NULL,       NULL, 		    1 << 7,	  0,	   0,       0, 		-1 },
	{ "Firefox",	    NULL,       NULL,           1,        0,       0,       0,      -1 }, 
	{ "Alacritty",  	NULL,       "Alacritty",	0,	      0,       1,       0,		-1 },
	{ "kitty",      	NULL,       NULL,    		0,        0,       1,       0,      -1 }, 
	{ "Xfce4-terminal", NULL,       NULL,    		0,        0,       1,       0,      -1 },   	
	{ NULL,         	NULL,       "Event Tester", 0,        0,       0,       1,      -1 }, /* xev */
	{ "cs2",        	 NULL,       NULL,      	1 << 7,   0,       0,       0,      -1 },
};


/* layout(s) */
static const float mfact     = 0.5; /* factor of master area size [0.05..0.95], % widht of the left window compared to the right window */
static const int nmaster     = 1;    /* number of clients in master area, how many windows are opened on the left side before windows get opened on the right side */
static const int resizehints = 1;    /* 1 means respect size hints in tiled resizals */
static const int lockfullscreen = 1; /* 1 will force focus on the fullscreen window */

/*Here you determine what symbols get used for the diffint layout-modes, if you add patches for different layouts then you can add symbols here for those layouts*/
static const Layout layouts[] = {
	/* symbol     arrange function */
	{ "[]=",      tile },    /* first entry is default */
	{ "><>",      NULL },    /* no layout function means floating behavior */
	{ "[M]",      monocle },
};

/* key definitions , Mod1Mask gets used for the alt-key, Mod4Mask gets used for the Windows-key. 
 * The function view switches to that workspace, the function toggleview shows another workspace at the same time, the function tag moves the focused window to another workspace.
 * The function toggletag pins a program ALSO to anothe workspace. This could for example come in handy if you want to open a PDF-reader, text-editor or LibreOffice-document  and browser. 
 * You want to have two of these programs visible at the same time and you can simply switch between two workspaces to see 2 out of the 3 programs.*/ 
#define MODKEY Mod4Mask
#define TAGKEYS(KEY,TAG) \
	{ MODKEY,                       KEY,      view,           {.ui = 1 << TAG} }, \
	{ MODKEY|ControlMask,           KEY,      toggleview,     {.ui = 1 << TAG} }, \
	{ MODKEY|ShiftMask,             KEY,      tag,            {.ui = 1 << TAG} }, \
	{ MODKEY|ControlMask|ShiftMask, KEY,      toggletag,      {.ui = 1 << TAG} },   

/* helper for spawning shell commands in the pre dwm-5.0 fashion. 
 * Here SHCMD(cmd) is definied as a shorthand notation for /bin/sh -c cmd, a little bit below where you can definie hotkeys for actions you can use 
 * "SHCMD in the function section to point out that you want to add your own command and then in the argument function you can give the command which 
 * you want to be executed in the terminal when you use the defined hotkey.*/
#define SHCMD(cmd) { .v = (const char*[]){ "/bin/sh", "-c", cmd, NULL } }

/* commands dmenucmd and termcmd are just different notations for these shell-commands. If you prefer another terminal than alacritty then you simply change alacritty to whatever you prefer.
 * If you prefer to use rofi then you simply change dmenu_run and the options to whatever you use for rofi. If you struggle with that then simply ignore dmenucmd and define it in the hotkeys
 * like you would do for any other shell command.  */
static char dmenumon[2] = "0"; /* component of dmenucmd, manipulated in spawn() */
static const char *dmenucmd[] = { "dmenu_run", "-m", dmenumon, "-fn", dmenufont, "-nb", normbgcolor, "-nf", normfgcolor, "-sb", selbordercolor, "-sf", selfgcolor, NULL };
static const char *termcmd[]  = { "alacritty", NULL };


static const Key keys[] = {
	/* modifier                     key        function        argument */
	/*These are the hotkeys for the windowmanagement itself, if you would add layouts and other funtions, like moving windows up or down in the stack-area
	 * then you should add those hotkeys to this section. It doesn't matter for the functioning because a simple array is used but it makes it more readable for the user
	 * In the 1st column you select two or more of the following keys: control, shift, alt, windows, note that ControlMask and Mod1Mask (alt) are for the left control- and alt-keys.
	 * ControlMask = control , ShiftMask = shift, Mod1Mask = alt, Mod4Mask = Windows, | can be read as + 
	 * In the 2nd column you define some letter, this kan be done with XK_d but if you don't know the notation then type XEV in the terminal, press the key and read the hexadecimal code,
	 * then you write that hexadecimal code (0x****) in the 2nd colum. 
	 * In the 3rd column you define the function, those functions are defined in the dwm.c file, with patches you can add functions to either the dmw.c-file or use separate files for that (easier)
	 * In the 4th column you give an "argument", either the shellcommand in the case of SHCMD or some function which is definied in the dwm.c file */
	{ ControlMask|ShiftMask,        XK_d,      spawn,          {.v = dmenucmd } }, // open dmenu, by default on the top of the screen 
	{ MODKEY,                       XK_Return, spawn,          {.v = termcmd } }, // open terminal, terminal is chosen higher in the file
	{ MODKEY,                       XK_b,      togglebar,      {0} }, // toggle show/hide panel
	{ MODKEY,                       XK_j,      focusstack,     {.i = +1 } }, // change focus to another window on that workspace
	{ MODKEY,                       XK_k,      focusstack,     {.i = -1 } }, // change focus to another window on that workspace in the other direction
	{ MODKEY,                       XK_h,      setmfact,       {.f = -0.05} }, // change split-ratio between master and stack
	{ MODKEY,                       XK_l,      setmfact,       {.f = +0.05} }, // change split-ratio between master and stack in the other direction
	{ MODKEY,                       XK_i,      incnmaster,     {.i = +1 } }, // increase number of windows in the master-area, can be used to for example have 2 windows on the left side and 2 on the right side
	{ MODKEY,                       XK_d,      incnmaster,     {.i = -1 } }, // decrease number of windows in the master-area
	{ MODKEY|ShiftMask,             XK_Return, zoom,           {0} }, 
	{ MODKEY,                       XK_Tab,    view,           {0} }, // switch to last used workspace (like how you would do that on Windows or KDE, switch between the last chosen window and the current one but then for the entire workspace)
	{ MODKEY|ShiftMask,             XK_c,      killclient,     {0} }, // close program in focused window
	
	/*In the next 3 lines the hotkeys are defined to select a layout, by default only tiling, floating and monocle (one window only visible)*/
	{ MODKEY,                       XK_t,      setlayout,      {.v = &layouts[0]} }, // tiled master/stack layout
	{ MODKEY,                       XK_f,      setlayout,      {.v = &layouts[1]} },
	{ MODKEY,                       XK_m,      setlayout,      {.v = &layouts[2]} }, // only show selected window on that workspace
	
	{ MODKEY,                       XK_space,  setlayout,      {0} }, // switch between the previously selected layout and current layout 
	{ MODKEY|ShiftMask,             XK_space,  togglefloating, {0} },
	{ MODKEY,                       XK_0,      view,           {.ui = ~0 } },
	{ MODKEY|ShiftMask,             XK_0,      tag,            {.ui = ~0 } }, /* This pins a program to a special workspace, whatever is on that workspace is visible on all workspaces
	this can for example be handy for streamers who want to have Chatterino visible on every workspace. */
	{ MODKEY,                       XK_comma,  focusmon,       {.i = -1 } }, /*select other monitor*/
	{ MODKEY,                       XK_period, focusmon,       {.i = +1 } }, /*select other monitor in the other direction */
	{ MODKEY|ShiftMask,             XK_comma,  tagmon,         {.i = -1 } }, /*move program to another monitor*/
	{ MODKEY|ShiftMask,             XK_period, tagmon,         {.i = +1 } }, /*move program to another monitor in the other direction*/
	{ MODKEY|ShiftMask,             XK_j,      rotatestack,    {.i = +1 } }, /*rotate programs over windows in one direction*/
	{ MODKEY|ShiftMask,             XK_k,      rotatestack,    {.i = -1 } }, /*rotate programs over windows in other direction*/
	/*Note that there are patches which let you move just one window up or down over the windows, if you need that then look at the following patches: cfacts, msstack, movestack*/
	
    /* Here the extra hotkeys for shellcommands are defined, to start whatever program you like in whatever way you like it.
     *  you can use both XK_* or a hexadecmial code to define a key in the second column, find the hexadecmial code with xev (X11 only) */
    { Mod1Mask|ControlMask,              XK_f,      spawn,          SHCMD("pcmanfm") },
    { Mod1Mask|ControlMask|ShiftMask,    XK_f,      spawn,          SHCMD("firefox") },
    { ControlMask|Mod1Mask|ShiftMask,    XK_k,      spawn,          SHCMD("firefox --private-window https://knmi.nl/nederland-nu/weer/waarnemingen")}, //open a private window for Firefox with a specific website
    { Mod1Mask|ControlMask|ShiftMask,    XK_t,      spawn,          SHCMD("~/Other/Kotatogram/Kotatogram") },
    { Mod1Mask|ControlMask,              XK_t,      spawn,          SHCMD("thunderbird") },
    { Mod1Mask|ControlMask,              XK_n,      spawn,          SHCMD("notepadqq") },
    { Mod1Mask|ControlMask,              XK_q,      spawn,          SHCMD("qpdfview") },
    { ControlMask|Mod1Mask,              XK_b,      spawn,          SHCMD("brave --password-store=basic") }, //the argument (password) is to avoid gnome-keyring getting used
    { ControlMask|ShiftMask|Mod1Mask,    XK_b,      spawn,	        SHCMD("brave --incognito --password-store=basic") }, //open a private window in the Brave browser
    { Mod1Mask|ControlMask,              0xff52,    spawn,          SHCMD("amixer -D pulse set Master 3%+") }, /*increase audio volume with 3%, you must use PulseAudio for this to work, if you don't use pulseaudio then you
    can either remove -D pulse or you change it a bit to work with pipewire or whatever */
    { Mod1Mask|ControlMask,              0xff54,    spawn,          SHCMD("amixer -D pulse set Master 3%-") }, //decrease audio-volume , 0xff52 is the uparrow, 0xff54 is the down-arrow
    { Mod1Mask|ControlMask|ShiftMask,    0xffff,    spawn,          SHCMD("systemctl suspend") },     
    { Mod1Mask|ControlMask|ShiftMask,    0xff56,    spawn,          SHCMD("shutdown now")},
    { Mod1Mask|ControlMask|ShiftMask,    0xff50,    spawn,          SHCMD("reboot") },
    {ControlMask|ShiftMask,              XK_l,      spawn,          SHCMD("lutris") },
    {ControlMask|Mod1Mask,               XK_d,      spawn,          SHCMD("deadbeef")}, 
    {ControlMask|ShiftMask,              XK_g,	    spawn,          SHCMD("geany")},
    {ControlMask|Mod1Mask,               XK_s,      spawn,          SHCMD("steam")},
    {ControlMask|Mod1Mask|ShiftMask,     XK_l,      spawn,          SHCMD("libreoffice")},
    {ControlMask|ShiftMask,		         XK_m,	    spawn,	        SHCMD("mumble")},
    
    //commands for making screenshots with scrot and xclip
    {MODKEY,                             XK_p,      spawn,          SHCMD("scrot -fs 'temp.png' -e 'xclip -selection clipboard -target image/png -i $f ; rm $f'")}, /*if you install scrot and xclip then you can make 
    a screenshot of the selected area, you see the mousecursor change and you can draw a rectangle, the screenshot gets stored on the clipboard (so use ctrl+v to paste it)*/ 
    {MODKEY|ShiftMask,                   XK_p,      spawn,          SHCMD("scrot -fs '~/Pictures/%d-%m-%y-%H%M%S.png'")}, //draw a rectangle but now the screenshot gets saved in a file, with the date and time as the filename
    {MODKEY,                             XK_o,      spawn,          SHCMD("scrot 'temp.png' -e 'xclip -selection clipboard -target image/png -i $f ; rm $f'")}, //screenshot of entire monitor(s)
    {MODKEY|ShiftMask,                   XK_o,      spawn,          SHCMD("scrot '~/Pictures/%d-%m-%y-%H%M%S.png'")},//screenshot of entire monitor(s) and saves as a file  
    {MODKEY|ShiftMask|Mod1Mask,   		 XK_o,      spawn,          SHCMD("scrot -a 0,0,2560,1440 '/home/user/Pictures/screenshots/%d-%m-%y-%H%M%S.png'")}, /* Assume a dual monitor setup with the monitor on the left side 
    being 2560 by 1440 pixels. This command will then take a screenshot of the left monitor only. With a multi-monitor setup both xrandr and scrot consider the output of all the monitors together as one big picture
    and you simply select the appropriate coordinates (based on the pixels of the monitors) to select the desired monitor to make a screenshot from */
    //see the man-page of scrot for more details, like only screenshotting the focused window, using a timeout or hiding the window-decorations.  
     
    {ControlMask|Mod1Mask|ShiftMask,     XK_m,      spawn,          SHCMD("pactl set-source-mute alsa_input.usb-MICE_MICROPHONE_USB_MICROPHONE_201308-00.mono-fallback 1")}, //mute microphone, you might need to change it a bit if you have a different microphone
    {ControlMask|Mod1Mask|ShiftMask,     XK_u,      spawn,          SHCMD("pactl set-source-mute alsa_input.usb-MICE_MICROPHONE_USB_MICROPHONE_201308-00.mono-fallback 0")}, //unmute microphone
    {ControlMask|Mod1Mask|ShiftMask,	 XK_p,	    spawn,	        SHCMD("sudo echo 150000000 > /sys/class/drm/card1/device/hwmon/hwmon4/power1_cap")},
    {ControlMask|Mod1Mask|ShiftMask,	 XK_n,	    spawn,          SHCMD("alacritty -e newsboat")}, // the -e argument for alacritty makes alacritty spawn a window and then execute whatever you add after -e, newsboat uses RSS-feeds
    {ControlMask|Mod1Mask|ShiftMask,	 XK_p,	    spawn,          SHCMD("alacritty -e pulsemixer")}, //pulsemixer is a nice alternative for pavucontrol, it works in the terminal and you can use it without a mouse
    {ControlMask|Mod1Mask|ShiftMask,	 XK_x,	    spawn,          SHCMD("xset r rate 155 70")}, //This was added by me because updating xorg annoyingly sets this to default settings, which is unusable for me.

    /* Here the keyboard-keys for the workspaces are defined. The 2nd argument is the workspace which was defined much higher in this file. For exmaple, if you use awesome-emoji's then simply paste those there.   
     * The first argument is the desired hotkey so if you prefer the top-row-numbers then change those hexadecimal codes to XK-1, XK-2 etcetera.*/
    TAGKEYS(0xff9c, 0)
    TAGKEYS(0xff99, 1)
    TAGKEYS(0xff9b, 2)
    TAGKEYS(0xff96, 3)
    TAGKEYS(0xff98, 5)
    TAGKEYS(0xff9d, 4)
    TAGKEYS(0xff95, 6)
    TAGKEYS(0xff97, 7)
    TAGKEYS(0xff9a, 8)
    TAGKEYS(0xff9e,	9)
    TAGKEYS(0xffff,	10)	
    TAGKEYS(0xff57,	11)	
    TAGKEYS(0xff56,	12)	
    TAGKEYS(0xff63,	13)	
    TAGKEYS(0xff50,	14)	
    TAGKEYS(0xff55,	15)	
    {MODKEY|ShiftMask, XK_q, quit, {0} }, //quit dwm, you would do this when you changed your recompiled it and start the new instance or when you switch to another windowmanager or a desktop-environment
};

/* mouse-button definitions*/
/* click can be ClkTagBar, ClkLtSymbol, ClkStatusText, ClkWinTitle, ClkClientWin, or ClkRootWin */
static const Button buttons[] = {
	/* click                event mask      button          function        argument */
	{ ClkTagBar,            MODKEY,         Button1,        tag,            {0} },
	{ ClkTagBar,            MODKEY,         Button3,        toggletag,      {0} },
	{ ClkWinTitle,          0,              Button2,        zoom,           {0} },
	{ ClkStatusText,        0,              Button2,        spawn,          {.v = termcmd } },
	{ ClkClientWin,         MODKEY,         Button1,        movemouse,      {0} },
	{ ClkClientWin,         MODKEY,         Button2,        togglefloating, {0} },
	{ ClkClientWin,         MODKEY,         Button3,        resizemouse,    {0} },
	{ ClkTagBar,            0,              Button1,        view,           {0} },
	{ ClkTagBar,            0,              Button3,        toggleview,     {0} },
	{ ClkTagBar,            MODKEY,         Button1,        tag,            {0} },
	{ ClkTagBar,            MODKEY,         Button3,        toggletag,      {0} },
};
